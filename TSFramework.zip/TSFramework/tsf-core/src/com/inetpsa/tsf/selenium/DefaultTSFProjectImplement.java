package com.inetpsa.tsf.selenium;

import com.intepsa.tsf.selenium.support.ITSFProjectInitialisation;

/**
 * DefaultTSFProjectImplement
 * @author e353062
 */
public class DefaultTSFProjectImplement implements ITSFProjectInitialisation {

	/** (non-Javadoc)
	 * @see com.intepsa.tsf.selenium.support.ITSFProjectInitialisation#initDatabaseConnexion
	 */
	public void initDatabaseConnexion() throws Exception {
		// TODO Auto-generated method stub

	}

	/** (non-Javadoc)
	 * @see com.intepsa.tsf.selenium.support.ITSFProjectInitialisation#initDatabaseContent
	 */
	public void initDatabaseContent() throws Exception {
		// TODO Auto-generated method stub

	}
	
	/** (non-Javadoc)
	 * @see com.intepsa.tsf.selenium.support.ITSFProjectInitialisation#initServices
	 */
	public void initServices() throws Exception {
		// TODO Auto-generated method stub

	}

	/** (non-Javadoc)
	 * @see com.intepsa.tsf.selenium.support.ITSFProjectInitialisation#cleanDatabase
	 */
	public void cleanDatabase() throws Exception {
		// TODO Auto-generated method stub

	}
	
	/** (non-Javadoc)
	 * @see com.intepsa.tsf.selenium.support.ITSFProjectInitialisation#isUseDatabase
	 */
	public void isUseDatabase() throws Exception {
		// TODO Auto-generated method stub

	}

}
