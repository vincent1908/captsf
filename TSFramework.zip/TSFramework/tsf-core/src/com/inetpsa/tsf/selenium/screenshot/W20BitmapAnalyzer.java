/**
 * 
 */
package com.inetpsa.tsf.selenium.screenshot;

/**
 * W20BitmapAnalyzer
 * @author e365712
 **/
public class W20BitmapAnalyzer extends GenericBitmapAnalyzer {

	
	
	
	
	
}
