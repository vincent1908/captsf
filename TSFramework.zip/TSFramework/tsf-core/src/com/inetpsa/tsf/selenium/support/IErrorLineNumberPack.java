package com.inetpsa.tsf.selenium.support;

/**
 * IErrorLineNumberPack
 * @author E365712
 */
public interface IErrorLineNumberPack {
	
    /**
     * getErrorLineNumberPack
     */
	void getErrorLineNumberPack();
}
